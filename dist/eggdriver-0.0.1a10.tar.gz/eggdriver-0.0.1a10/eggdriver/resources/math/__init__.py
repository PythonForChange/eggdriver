from eggdriver.resources.math.algorithms import *
from eggdriver.resources.math.theoric import *
from eggdriver.resources.math.float import *
from eggdriver.resources.math.functions import *
from eggdriver.resources.math.linear import *
from eggdriver.resources.math.polynomial import *
from eggdriver.resources.math.constants import *