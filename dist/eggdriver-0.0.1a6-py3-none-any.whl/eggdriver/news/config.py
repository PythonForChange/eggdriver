from datetime import date
todaysDate = date.today()

# News Config
files = ["README.md"]
year = int(todaysDate.year)