_author="eanorambuena"
_author_email="eanorambuena@uc.cl"

eggConsoleCommands=[
  "nqs",
  "new",
  "login,"
  "register",
  "install",
  "upgrade",
  "pull",
  "help",
  "clear",
  "end"
]

developerConsoleCommands=[
  "display",
  "compile",
  "save",
  "run",
  "delay",
  "end"
]

nqsCommands=[
  "host",
  "shots",
  "hist",
  "draw",
  "inject",
  "function",
  "clear",
  "delay"
]

journalistConsoleCommands=[
  "save",
  "end"
]