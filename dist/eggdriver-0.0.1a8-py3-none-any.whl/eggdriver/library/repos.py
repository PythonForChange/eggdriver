from eggdriver.resources.modules import Repo

# NQS=Repo("PythonForChange", "eggdriver")
# nqs=NQS.pull("nqs")