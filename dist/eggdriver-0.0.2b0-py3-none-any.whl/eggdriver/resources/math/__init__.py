from eggdriver.resources.math.algorithms import solve, root
from eggdriver.resources.math.theoric import *
from eggdriver.resources.math.float import *
from eggdriver.resources.math.polynomial import Polynomial
from eggdriver.resources.math.constants import inf, e, pi
from eggdriver.resources.math.functions import log, ln, cos, sin, tan
from eggdriver.resources.math.linear import Vector, Matrix
from eggdriver.resources.math.calculus import *

