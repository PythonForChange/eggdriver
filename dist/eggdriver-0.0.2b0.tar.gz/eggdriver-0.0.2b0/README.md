# eggdriver

Your proyect trusted driver.

## Quick start

### 1. Install eggdriver

    pip install eggdriver

### 2. (Optional) Create the file **eggconfig.py** and then write in it the following lines:

    username, password = "{your user}", "{your password}"

    pypi = {<br>
        "user" : "{your PyPI user or "\__token__"}",
        "password" : "{your PyPI password or token}"
    }


